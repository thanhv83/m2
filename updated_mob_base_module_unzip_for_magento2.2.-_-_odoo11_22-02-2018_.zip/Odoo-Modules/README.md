# Instructions

this directory contains odoo module which is compatible with version 11.0

# Installation

follow below steps for odoo module installation.

1. Place all odoo module files inside your Odoo addons. 
2. then activate odoo developer mode, after that you'll be able to see extended menu's
3. Inside Apps menu click on "Update Apps List" menu
4. after that you'll be able to see the modules. then simply install it and proceed.