# Installation

Odoo Bridge For Magento2  module installation is very easy, please follow the steps for installation-

Note:- current modules are compatible with magento v2.2.* and odoo v11.0.

1. Unzip the respective extension zip and then move "app" folder (which is inside "src" folder) into magento root directory.

2. Run following commands via terminal

    php bin/magento setup:upgrade

    php bin/magento setup:di:compile

    php bin/magento setup:static-content:deploy


3. Flush the cache and reindex all.

    php bin/magento cache:flush

    php bin/magento indexer:reindex

now module is properly installed

# User Guide

For Magento 2.2.* Odoo Bridge module's working process follow user guide - http://webkul.com/blog/odoo-bridge-for-magento-v2/

# Support

Find us our support policy - https://store.webkul.com/support.html/

# Refund

Find us our refund policy - https://store.webkul.com/refund-policy.html/

---------------------------------------------------------------------------------------- 
Note - This readme file is strictly need to use when you have purchased the software from 
webkul store i.e https://store.webkul.com . If you purchase the module from magento marketplace 
connect this readme file will not work.