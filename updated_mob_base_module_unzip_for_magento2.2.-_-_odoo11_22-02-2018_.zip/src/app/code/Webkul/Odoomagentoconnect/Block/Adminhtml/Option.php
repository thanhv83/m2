<?php
namespace Webkul\Odoomagentoconnect\Block\Adminhtml;

/**
 * Webkul Odoomagentoconnect Option Block
 * @category  Webkul
 * @package   Webkul_Odoomagentoconnect
 * @author    Webkul
 * @copyright Copyright (c) 2010-2017 Webkul Software Private Limited (https://webkul.com)
 * @license   https://store.webkul.com/license.html
 */

class Option extends \Magento\Backend\Block\Widget\Grid\Container
{
}
