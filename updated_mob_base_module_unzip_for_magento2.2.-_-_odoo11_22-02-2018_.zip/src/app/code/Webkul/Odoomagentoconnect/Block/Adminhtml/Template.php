<?php
namespace Webkul\Odoomagentoconnect\Block\Adminhtml;

/**
 * Webkul Odoomagentoconnect Template Block
 * @category  Webkul
 * @package   Webkul_Odoomagentoconnect
 * @author    Webkul
 * @copyright Copyright (c) 2010-2017 Webkul Software Private Limited (https://webkul.com)
 * @license   https://store.webkul.com/license.html
 */

class Template extends \Magento\Backend\Block\Template
{

}
